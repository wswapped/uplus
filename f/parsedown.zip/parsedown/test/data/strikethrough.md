~~strikethrough~~

here's ~~one~~ followed by ~~another one~~

~~ this ~~ is not one neither is ~this~