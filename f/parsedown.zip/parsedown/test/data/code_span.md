a `code span`

`this is also a codespan` trailing text

`and look at this one!`

single backtick in a code span: `` ` ``

backtick-delimited string in a code span: `` `foo` ``

`sth `` sth`