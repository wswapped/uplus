an autolink http://example.com

inside of brackets [http://example.com], inside of braces {http://example.com},  inside of parentheses (http://example.com)

trailing slash http://example.com/ and http://example.com/path/