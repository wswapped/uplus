<?php
define('hostname', 'localhost');
define('user', 'clement');
define('password', 'clement123');
define('databaseName', 'test_offline');
?>