<?php
	$conn = $db = new mysqli("localhost", "churches", "churches100" , "churches");
?>