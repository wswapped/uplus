<?php
	$conn = $db = new mysqli("localhost", "root", "" , "churches");
?>