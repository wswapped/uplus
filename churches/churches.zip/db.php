<?php
	// $conn = $db = new mysqli("localhost", "churches", "churches100" , "churches");
	$conn = $db = new mysqli("localhost", "root", "" , "churches");
?>
