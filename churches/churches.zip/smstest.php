<?php
	include "functions.php";
	var_dump(sendsms("0727652558", "hI TEST"));
?>