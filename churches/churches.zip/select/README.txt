A Pen created at CodePen.io. You can find this one at https://codepen.io/i_cant_rap/pen/qNdXyj.

 It's a selectize multiselect. With bulma.