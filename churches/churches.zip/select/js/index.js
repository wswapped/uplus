$(function() {
  $('select').selectize();
});